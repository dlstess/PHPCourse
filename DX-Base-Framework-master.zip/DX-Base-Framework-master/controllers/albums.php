<?php

namespace Controllers;

class Albums_Controller extends Master_Controller {
	
}